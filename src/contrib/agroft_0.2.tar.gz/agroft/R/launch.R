launch <- function(){
  shiny::runApp(system.file('app', package='agroft'))
}